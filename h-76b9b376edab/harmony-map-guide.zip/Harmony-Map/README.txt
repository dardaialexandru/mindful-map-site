The Harmony Map, from The Mindful Map (https://themindfulmap.org)

Five pages:
1. The loop of a hard day
2. Which layer is leading today?
3. The calm-mind trap
4. How harmony appears
5. Seven doors, seven days

Reflections, not medical advice. If you feel unwell for a long time, please talk to a professional.
